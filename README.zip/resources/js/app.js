// MODIFIED START - 2025-10-10 19:09 - Import Bootstrap to enable JS components like modals.
import 'bootstrap';
// MODIFIED END - 2025-10-10 19:09
import './bootstrap';
