<?php
    $userGroups = $user->groups ? $user->groups->pluck('cn')->flatten()->toArray() : [];
?>
<div class="modal fade" id="editUserModal-<?php echo e($user->getConvertedGuid()); ?>" tabindex="-1" aria-labelledby="editUserModalLabel-<?php echo e($user->getConvertedGuid()); ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="<?php echo e(route('users.update', ['guid' => $user->getConvertedGuid()])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="domain" value="<?php echo e($domain); ?>">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUserModalLabel-<?php echo e($user->getConvertedGuid()); ?>">Edit User: <?php echo e($user->getFirstAttribute('cn')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    
                    <?php if(session('open_modal') == '#editUserModal-'.$user->getConvertedGuid() && (session('error') || $errors->any())): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php if(session('error')): ?>
                                    <li><?php echo e(session('error')); ?></li>
                                <?php endif; ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="first_name_<?php echo e($user->getConvertedGuid()); ?>" class="form-label">First Name</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="first_name_<?php echo e($user->getConvertedGuid()); ?>" name="first_name" value="<?php echo e(old('first_name', $user->getFirstAttribute('givenname'))); ?>" required>
                             
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="last_name_<?php echo e($user->getConvertedGuid()); ?>" class="form-label">Last Name</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="last_name_<?php echo e($user->getConvertedGuid()); ?>" name="last_name" value="<?php echo e(old('last_name', $user->getFirstAttribute('sn'))); ?>" required>
                             
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="samaccountname_<?php echo e($user->getConvertedGuid()); ?>" class="form-label">Username</label>
                        <input type="text" class="form-control" id="samaccountname_<?php echo e($user->getConvertedGuid()); ?>" name="samaccountname" value="<?php echo e($user->getFirstAttribute('samaccountname')); ?>" readonly disabled>
                        <div class="form-text">The username (sAMAccountName) cannot be changed.</div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="date_of_birth_<?php echo e($user->getConvertedGuid()); ?>" class="form-label">Date of Birth</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date_of_birth_<?php echo e($user->getConvertedGuid()); ?>" name="date_of_birth" value="<?php echo e(old('date_of_birth', $user->getFirstAttribute('extensionattribute1'))); ?>" required>
                             
                            <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="mobile_number_<?php echo e($user->getConvertedGuid()); ?>" class="form-label">Mobile Number</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="mobile_number_<?php echo e($user->getConvertedGuid()); ?>" name="mobile_number" value="<?php echo e(old('mobile_number', $user->getFirstAttribute('mobile'))); ?>" required>
                             
                            <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                    </div>

                    <div class="row">
                         <div class="col-md-6 mb-3">
                            <label for="account_expires_<?php echo e($user->getConvertedGuid()); ?>" class="form-label">Account Expiry (Optional)</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['account_expires'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="account_expires_<?php echo e($user->getConvertedGuid()); ?>" name="account_expires" value="<?php echo e(old('account_expires', $user->accountexpires instanceof \Carbon\Carbon ? $user->accountexpires->format('Y-m-d') : '')); ?>">
                             
                            <?php $__errorArgs = ['account_expires'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Optional Groups</label>
                        <div class="border rounded p-2" style="max-height: 150px; overflow-y: auto;">
                            <?php $__currentLoopData = $optionalGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="groups[]" value="<?php echo e($group); ?>" id="edit_group_<?php echo e($group); ?>_<?php echo e($user->getConvertedGuid()); ?>"
                                    <?php echo e(in_array($group, old('groups', $userGroups)) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="edit_group_<?php echo e($group); ?>_<?php echo e($user->getConvertedGuid()); ?>">
                                    <?php echo e($group); ?>

                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <hr class="my-4">
                    <h5 class="mb-3">Reset Password (Optional)</h5>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="password_<?php echo e($user->getConvertedGuid()); ?>" class="form-label">New Password</label>
                            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password_<?php echo e($user->getConvertedGuid()); ?>" name="password">
                             
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="password_confirmation_<?php echo e($user->getConvertedGuid()); ?>" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="password_confirmation_<?php echo e($user->getConvertedGuid()); ?>" name="password_confirmation">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\Edward\Desktop\keystone\resources\views/users/edit.blade.php ENDPATH**/ ?>